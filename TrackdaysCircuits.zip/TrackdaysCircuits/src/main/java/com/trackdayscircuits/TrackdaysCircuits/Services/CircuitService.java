package com.trackdayscircuits.TrackdaysCircuits.Services;

import java.util.List;
import com.trackdayscircuits.TrackdaysCircuits.model.Circuits;

public interface CircuitService {

    // Guardar un Circuito en la bbdd:
    void saveCircuit(Circuits circuit);

    // Eliminar un Circuito de la bbdd:
    void deleteCircuit(Long id);

    // Buscar un Circuito por su id en la bbdd:
    Circuits buscarId(Long id);

    // Listar todos los Circuitos guardados en la bbdd:
    List<Circuits> circuitsList();
}

