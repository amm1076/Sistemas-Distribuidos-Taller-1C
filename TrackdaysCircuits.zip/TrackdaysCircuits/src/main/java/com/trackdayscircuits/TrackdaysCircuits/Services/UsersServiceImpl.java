package com.trackdayscircuits.TrackdaysCircuits.Services;

import com.trackdayscircuits.TrackdaysCircuits.Repositories.UsuariosRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.trackdayscircuits.TrackdaysCircuits.model.Users;

import java.util.List;

@Service
public class UsersServiceImpl implements UsersService, UserDetailsService {

    private final UsuariosRepository usuariosRepository;

    private final PasswordEncoder passwordEncoder;

    public UsersServiceImpl(UsuariosRepository usuariosRepository) {
        this.usuariosRepository = usuariosRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    public void saveUser(Users user) {
        // Para evitar volver a cifrar una contraseña ya cifrada
        if (user.getPassword() != null) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        usuariosRepository.save(user);
    }

    @Override
    public boolean validateAuthentication(String username, String password) {
        Users user = usuariosRepository.findUsuariosBynombreUser(username);
        return user != null && passwordEncoder.matches(password, user.getPassword());
    }

    @Override
    public List<Users> userList() {
        return usuariosRepository.findAll();
    }

    @Override
    public void deleteUser(Long id) {
        usuariosRepository.deleteById(id.longValue());
    }

    @Override
    public Users buscarId(Long id) {
        return usuariosRepository.findById(id).orElse(null);
    }


    // Metodo requerido por Spring Security
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users user = usuariosRepository.findUsuariosBynombreUser(username);
        if (user == null) {
            throw new UsernameNotFoundException("Usuario no encontrado: " + username);
        }

        return new org.springframework.security.core.userdetails.User(
                user.getNombreUser(),
                user.getPassword(),
                List.of(new SimpleGrantedAuthority("ROLE_USER"))
        );
    }

}