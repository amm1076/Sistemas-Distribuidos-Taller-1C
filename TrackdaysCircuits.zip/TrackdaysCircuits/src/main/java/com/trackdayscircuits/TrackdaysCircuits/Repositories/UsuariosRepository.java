package com.trackdayscircuits.TrackdaysCircuits.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.trackdayscircuits.TrackdaysCircuits.model.Users;
@Repository
public interface UsuariosRepository extends JpaRepository<Users, Long> {

    // Encontrar usuario por su nombre:
    Users findUsuariosBynombreUser(String username);

}