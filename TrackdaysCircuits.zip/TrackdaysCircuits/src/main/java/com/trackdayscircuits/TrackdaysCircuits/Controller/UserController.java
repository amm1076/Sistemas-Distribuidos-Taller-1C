package com.trackdayscircuits.TrackdaysCircuits.Controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import com.trackdayscircuits.TrackdaysCircuits.model.Users;
import com.trackdayscircuits.TrackdaysCircuits.Services.UsersServiceImpl;

import java.util.List;

@Controller
public class UserController {

    private final UsersServiceImpl usersService;

    public UserController(UsersServiceImpl usersService) {
        this.usersService = usersService;
    }

    @GetMapping("/login")
    public String mostrarpantallalogin() {
        return "login";
    }

    @GetMapping("/")
    public String home() {
        return "index"; // o el nombre de tu plantilla principal
    }

    @PostMapping("/login")
    public String controlLogin(@RequestParam("username") String username,
                               @RequestParam("password") String password,
                               HttpSession session,
                               Model model) {

        if (usersService.validateAuthentication(username, password)) {
            // Guardamos el usuario autenticado en sesión
            session.setAttribute("Usuario_Actual", username);

            return "redirect:/";
        } else {
            model.addAttribute("error", "Usuario o contraseña inválidos");
            return "login";
        }
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/usuarios")
    public String Listarusuarios(Model model) {
        List<Users> listau = usersService.userList();
        model.addAttribute("listau", listau);
        return "usuarios";
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/Registrarusuario")
    public String mostrarFormularioRegistro(Model model) {
        model.addAttribute("Usuario", new Users());
        return "Registrarusuario";
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/Registrarusuario")
    public String guardarNuevoCircuito(@ModelAttribute("Usuario") Users nuevoUsuario) {
        usersService.saveUser(nuevoUsuario);
        return "redirect:/usuarios";
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/usuarios/{id}/delete")
    public String eliminarUsuario(@PathVariable("id") Long id) {
        usersService.deleteUser(id);
        return "redirect:/usuarios";
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/modificarUsuario/{idUsuario}")
    public String modificarUsuario(@PathVariable("idUsuario") Long id, Model model) {
        Users usuario = usersService.buscarId(id);
        usuario.setPassword(""); // Limpia la contraseña para que no aparezca en el formulario
        model.addAttribute("Usuario", usuario);
        return "modificarUsuario";
    }

    @PreAuthorize("hasRole('USER')")
    @PostMapping("/modificarUsuario/{id}/update")
    public String actualizarUsuario(@PathVariable("id") Long id, @ModelAttribute Users usuarioModificado) {
        // Obtener usuario original desde la BBDD
        Users usuarioExistente = usersService.buscarId(id);

        // Copiar campos editables
        usuarioExistente.setNombreUser(usuarioModificado.getNombreUser());
        usuarioExistente.setEmail(usuarioModificado.getEmail());

        // actualizo la contraseña si se ha introducido una nueva
        if (usuarioModificado.getPassword() != null && !usuarioModificado.getPassword().isBlank()) {
            usuarioExistente.setPassword(usuarioModificado.getPassword()); // Sin encriptar la encripto en UserServiceImpl
        }
        // Si está vacía o nula, no la modifico, queda la antigua

        usersService.saveUser(usuarioExistente);
        return "redirect:/usuarios";
    }
}
