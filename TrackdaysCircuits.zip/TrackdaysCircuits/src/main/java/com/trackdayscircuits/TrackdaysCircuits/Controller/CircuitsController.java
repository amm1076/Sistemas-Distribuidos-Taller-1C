package com.trackdayscircuits.TrackdaysCircuits.Controller;

import com.trackdayscircuits.TrackdaysCircuits.Services.CircuitService;
import com.trackdayscircuits.TrackdaysCircuits.model.Circuits;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;


@Controller
public class CircuitsController {

	private final CircuitService circuitService;

	public CircuitsController(CircuitService circuitService) {
		this.circuitService = circuitService;
	}

	@GetMapping("/index")
	public String home() {
		return "index"; // Carga templates/index.html
	}

	@GetMapping("/service")
	public String services() {
		return "service"; // Carga templates/service.html
	}

	@GetMapping("/circuits")
	public String listacircuitos(Model model) {
		List<Circuits> lista = circuitService.circuitsList();
		model.addAttribute("lista", lista);
		return "circuits";
	}
	@PreAuthorize("hasRole('USER')")
	@PostMapping("/circuits/{id}/delete")
	public String eliminarCircuito(@PathVariable("id") Long id) {
		circuitService.deleteCircuit(id);
		return "redirect:/circuits";
	}

	@PreAuthorize("hasRole('USER')")
	@GetMapping("/Registrarcircuito")
	public String mostrarFormularioRegistro(Model model) {
		model.addAttribute("Circuito", new Circuits());
		return "registrarCircuito";
	}

	@PreAuthorize("hasRole('USER')")
	@PostMapping("/Registrarcircuito")
	public String guardarNuevoCircuito(@ModelAttribute("Circuito") Circuits nuevoCircuito) {
		circuitService.saveCircuit(nuevoCircuito);
		return "redirect:/circuits";
	}

	@GetMapping("/contact")
	public String contact() {
		return "contact";
	}

	@GetMapping("/booking")
	public String booking() {
		return "circuits";
	}

	@GetMapping("/team")
	public String team() {
		return "team";
	}

	@PreAuthorize("hasRole('USER')")
	@GetMapping("/modificarCircuito/{idCircuito}")
	public String modificarCircuito(@PathVariable("idCircuito") Long id, Model model) {
		Circuits circuito = circuitService.buscarId(id);
		model.addAttribute("Circuito", circuito);
		return "modificarCircuito";
	}

	@PreAuthorize("hasRole('USER')")
	@PostMapping("/modificarCircuito/{id}/update")
	public String actualizarCircuito(@PathVariable("id") Long id, Circuits circuitoModificado) {
		circuitService.saveCircuit(circuitoModificado);
		return "redirect:/circuits";
	}


	@GetMapping("/404")
	public String notFound() {
		return "404";
	}
}