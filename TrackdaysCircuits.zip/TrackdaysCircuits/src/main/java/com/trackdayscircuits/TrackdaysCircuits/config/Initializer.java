package com.trackdayscircuits.TrackdaysCircuits.config;

import com.trackdayscircuits.TrackdaysCircuits.model.Circuits;
import com.trackdayscircuits.TrackdaysCircuits.model.Users;
import com.trackdayscircuits.TrackdaysCircuits.Repositories.UsuariosRepository;
import com.trackdayscircuits.TrackdaysCircuits.Repositories.circuitsRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class Initializer {

    private final UsuariosRepository usuarioRepository;
    private final circuitsRepository circuitsRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${execution.mode}")
    private String executionMode;

    public Initializer(UsuariosRepository usuarioRepository, circuitsRepository circuitsRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.circuitsRepository = circuitsRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void initialize() {
        if ("1".equalsIgnoreCase(executionMode)) {
            crearUsuario();
            crearCircuitos();
        }
    }

    private void crearUsuario() {
        if (usuarioRepository.findAll().isEmpty()) {
            Users user = new Users();
            user.setEmail("amm@ubu.es");
            user.setNombreUser("Admin");
            user.setPassword(passwordEncoder.encode("admin"));
            usuarioRepository.save(user);
        }
    }

    private void crearCircuitos() {
        if (circuitsRepository.findAll().isEmpty()) {
            circuitsRepository.save(new Circuits("Nurburgring", "Alemania", 20));
            circuitsRepository.save(new Circuits("Jarama", "España", 4));
            circuitsRepository.save(new Circuits("Le Mans", "Francia", 14));
        }
    }
}