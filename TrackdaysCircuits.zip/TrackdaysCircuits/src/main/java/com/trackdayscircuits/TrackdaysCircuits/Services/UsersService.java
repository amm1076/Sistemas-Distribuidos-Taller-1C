package com.trackdayscircuits.TrackdaysCircuits.Services;
import com.trackdayscircuits.TrackdaysCircuits.model.Users;

import java.util.List;

public interface  UsersService {

    void saveUser(Users user);

    boolean validateAuthentication(String username, String password);

    // Listar todos los Circuitos guardados en la bbdd:
    List<Users> userList();

    // Eliminar un Circuito de la bbdd:
    void deleteUser(Long id);

    Users buscarId(Long id);

}