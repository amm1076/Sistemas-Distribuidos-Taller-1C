package com.trackdayscircuits.TrackdaysCircuits.Services;

import java.util.List;
import com.trackdayscircuits.TrackdaysCircuits.model.Circuits;
import com.trackdayscircuits.TrackdaysCircuits.Repositories.circuitsRepository;
import org.springframework.stereotype.Service;

@Service
public class CircuitServiceImpl implements CircuitService {

    //Para acceder a todos los métodos de JPA:
    private final circuitsRepository CircuitRepository;

    // Constructor:
    public CircuitServiceImpl(circuitsRepository CircuitRepository) {
        this.CircuitRepository = CircuitRepository;
    }

    @Override
    public void saveCircuit(Circuits circuit) {
        CircuitRepository.save(circuit);
    }

    @Override
    public void deleteCircuit(Long id) {
        CircuitRepository.deleteById(id.longValue());
    }

    @Override
    public Circuits buscarId(Long id) {
        return CircuitRepository.getReferenceById(id.longValue());
    }

    @Override
    public List<Circuits> circuitsList() {
        return  CircuitRepository.findAll();
    }
}
