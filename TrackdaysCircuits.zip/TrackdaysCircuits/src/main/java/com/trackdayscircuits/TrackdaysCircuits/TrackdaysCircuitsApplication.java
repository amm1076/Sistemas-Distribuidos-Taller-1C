package com.trackdayscircuits.TrackdaysCircuits;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import java.util.Objects;

import com.trackdayscircuits.TrackdaysCircuits.model.Users;
import com.trackdayscircuits.TrackdaysCircuits.model.Circuits;
import com.trackdayscircuits.TrackdaysCircuits.Repositories.circuitsRepository;
import com.trackdayscircuits.TrackdaysCircuits.Repositories.UsuariosRepository;

@SpringBootApplication
public class TrackdaysCircuitsApplication {

	// Crear variable pública para el usuario logeado:
	public static String Usuario_Actual = null;

	public static void main(String[] args) {
		SpringApplication.run(TrackdaysCircuitsApplication.class, args);
	}
}
