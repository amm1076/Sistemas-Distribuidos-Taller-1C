package com.trackdayscircuits.TrackdaysCircuits.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class Users {
    public Users(String nombreUser, String email, String password) {
        this.nombreUser = nombreUser;
        this.email = email;
        this.password = password;
    }

    // Atributos
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "email")
    private String email;

    @Column(name = "nombreUser")
    private String nombreUser;

    @Column(name = "password")
    private String password;

}
