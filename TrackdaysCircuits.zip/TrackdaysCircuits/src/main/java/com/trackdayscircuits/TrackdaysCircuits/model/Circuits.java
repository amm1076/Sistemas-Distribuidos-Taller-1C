package com.trackdayscircuits.TrackdaysCircuits.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "circuit")
@Getter
@Setter
@NoArgsConstructor

public class Circuits {
    public Circuits(String nombre, String pais, int km) {
        this.nombre = nombre;
        this.pais = pais;
        this.km = km;
    }
    // Atributos
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long id;

    public String nombre;
    public String pais;
    public int km;

}